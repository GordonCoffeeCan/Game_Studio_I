﻿using UnityEngine;
using System.Collections;

//This script only does two things: it reports back to the game manager if the ball hits the Collider2D on this object
//and it plays a sound when that happens
public class WallControl : MonoBehaviour {
	GameObject manager; //declare a reference to the game manager, which we will fill using code in Start()
	AudioSource audioSource; //declare a refernece to the AudioSource component on this GameObject

	// Start() is called at the beginning of the game.
	void Start () {
		manager = GameObject.Find ("GameManager"); //this sets up the manager variable with a reference to the manager
		audioSource = GetComponent<AudioSource>(); //set up the audio variable with a reference to the AudioSource component on this object
	}

	//OnCollisionEnter2D() is called by the unity engine under the following conditions
	//1. The object that the script is on has a Rigidbody2D on it and a Collider2D (could be a box, circle, etc)
	//2. The object that the script is on is touching another object with *at least* a collider on it.
	//The function receives a special Collision2D object as a parameter, which has information about the collision in it

	void OnCollisionEnter2D(Collision2D thisCollision){
		if (thisCollision.collider.tag == "Ball") { //did we hit an object with the tag "Ball"?
			manager.SendMessage ("BallHitWall"); //tell the manager the ball hit the wall
			audioSource.Play(); //play the clip currently set on the AudioSource
		}
	}
}
