﻿using UnityEngine;
using System.Collections;

//This script only does one thing: it reports back to the game manager if the ball hits the trigger Collider on this object
public class KillzoneControl : MonoBehaviour {
	GameObject manager;
	AudioSource audioSource;

	// Start() is called at the beginning of the game
	void Start () {
		manager = GameObject.Find ("GameManager"); //fill the manager variable with a reference to the Game Manager
		audioSource = GetComponent<AudioSource>(); //fill the audio variable with a reference to the AudioSource component on this object
	}

	//OnTriggerEnter2D() is called by the unity engine under the following conditions
	//1. The object that the script is on has a Collider2D set to 'Trigger' mode(could be a box, circle, etc)
	//2. The object that the script is on is touching another object with *at least* a Collider2D on it.
	//The function receives the colliding Collider2D component as a parameter

	void OnTriggerEnter2D(Collider2D colliderThatHitMe){
		if (colliderThatHitMe.tag == "Ball") { //check to see if the colliding object had the tag 'Ball'
			manager.SendMessage ("BallWentOut"); //tell the game manager that the ball hit this zone.
			audioSource.Play(); //play the clip currently set on this AudioSource
		}
	}
}
