﻿using UnityEngine;
using System.Collections;

//This script is just for one thing: making the player jump when you hit the space bar
public class PlayerControl : MonoBehaviour {
	
	//public variables like this one are accessible to other scripts, and often set in the inspector
	//they're great for tunable variables because we can change them while the game is running
	public float jumpSpeed; 
	public Sprite[] sprites; //store a couple of sprite images and use them to change the renderer. We'll do real animations soon.

	//private variables have to be set in code, like Phaser's global variables
	Rigidbody2D rb;
	AudioSource audioSource;
	SpriteRenderer spriteRenderer;

	// Start is called at the beginning of the game
	void Start () {
		//fill the Rigidbody2D variable with a reference to the Rigidbody2D on this GameObject
		rb = GetComponent<Rigidbody2D> (); 

		//same for the AudioSource
		audioSource = GetComponent<AudioSource>();

		//same for the Sprite Renderer
		spriteRenderer = GetComponent<SpriteRenderer>();
	}
	
	// FixedUpdate is called along with the physics engine, at regular time intervals 
	// It's often used whenever you want to interact with physics components, as we do here
	void FixedUpdate () {
		//Input.GetButtonDown is called only immediately after the button is pressed
		//if you want to check if a button is held down, use Input.GetButton
		//Input.GetButtonDown looks for the button named in the Input manager (Edit->Project Settings->Input)
		//By default the space bar and A button on a controller are mapped to 'Jump'
		if (Input.GetButtonDown ("Jump")) { 
			rb.velocity = new Vector2 (0, jumpSpeed); //set the vertical velocity of the Rigidbody2D 

			//slightly randomize the pitch to make it less monotonous
			audioSource.pitch = Random.Range(0.8f,1.2f);
			audioSource.Play(); //play the clip currently set on this AudioSource

			spriteRenderer.sprite = sprites [1]; //switch to the jump frame
		}
	}

	//OnCollisionEnter2D() is called by the unity engine under the following conditions
	//1. The object that the script is on has a Rigidbody2D on it and a Collider2D (could be a box, circle, etc)
	//2. The object that the script is on is touching another object with *at least* a collider on it.
	//The function receives a special Collision2D object as a parameter, which has information about the collision in it

	void OnCollisionEnter2D(Collision2D thisCollision){
		if (thisCollision.collider.tag != "Ball") { //if we didn't hit the ball we must have hit the ground
			spriteRenderer.sprite = sprites [0]; //switch to the idle frame
		}
	}
}
