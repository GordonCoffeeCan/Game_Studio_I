﻿using UnityEngine;
using System.Collections;
//Simple Caveman Pong clone
//Bennett Foddy
//NYU Game Center 2016

//This manager script handles the core logic of the game, keeping and displaying the score
//And receiving messages from the other scripts.
public class ManagerControl : MonoBehaviour {

	//public variables like this one are accessible to other scripts, and often set in the inspector
	//they're great for tunable variables because we can change them while the game is running
	//sometimes it's just easier to set a reference to another object by dragging it into a public variable in the inspector
	public TextMesh scoreText; //reference to the 3D score text object, set in the inspector
	public GameObject ballPrefab; //reference to the ball prefab object, which lives in the Project window

	//private variables have to be set in code, like Phaser's global variables
	int score;
	GameObject currentBall; //a reference to the current ball in play
	Vector3 ballStartPosition; //we'll save the ball's starting position to this variable

	// Start is called by the Unity engine when the game starts, like Phaser's 'create'
	void Start () {
		score = 0; 

		//This find function will stop looking when it finds the first object with the tag 'Ball'
		currentBall = GameObject.FindGameObjectWithTag ("Ball");

		//Later we'll want to remember where the first ball was when the game started, so we store that in
		//a Vector3, which is how positions are stored in Unity Transform components
		ballStartPosition = currentBall.transform.position;
	}
	
	// Update is called once per frame, just like in Phaser
	void Update () {
		scoreText.text = score.ToString(); //in C# you can't just put a number in a text object - you need to convert it.
		//it is also legal to write:
		//scoreText.text = "Score: " + score;
		//but not legal to write:
		//scoreText.text = score;

		//if we don't have the currentBall set to an object, it means the ball was destroyed. We need to make a new one
		if (currentBall == null) {
			//Instantiate makes a copy of a prefab object at a specified position and rotation.
			//Generally your prefabs should live as files in the project window, but sometimes they will
			//live in the scene.
			//Don't worry too much about 'Quaternion.identity'. It just means 'no rotation'
			currentBall = Instantiate (ballPrefab, ballStartPosition, Quaternion.identity) as GameObject;
		}
	}
		
	//To receive the message 'BallHitWall' we need to have a public function with that name
	//This is called by the WallControl script on the Wall, using SendMessage()
	public void BallHitWall(){
		Debug.Log ("player scored"); //This works the same way 'console.log' works in Phaser.
		score += 1;
	}

	//To receive the message 'BallWentOut' we need to have a public function with that name
	//This is called by the KillzoneControl script on the Killzone, using SendMessage()
	public void BallWentOut(){
		score = 0; //reset the score
		Destroy (currentBall); //destroy the current ball
	}
}
