﻿using UnityEngine;
using System.Collections;

public class BallControl : MonoBehaviour {

	//public variables are accessible by other scripts, and are often set in the inspector
	//they're great for tunable variables, like these, since we can edit them in play mode.
	public float horizontalSpeed; //the ball's constant horizontal speed
	public float maxVerticalSpeed; //the maximum vertical speed

	//private variables are more like the global variables in Phaser, and 
	//they can't be accessed by other scripts
	Rigidbody2D rb; //a reference to the Rigidbody2D component on this object

	// Use this for initialization
	void Start () {
		//first we fill our Rigidbody2D reference with the component on this obejct
		rb = GetComponent<Rigidbody2D> ();
		//then give it a starting velocity, up and to the right (remember positive Y is up in Unity!)
		rb.velocity = new Vector2 (0.5f, 0.5f); 
	}
	
	// FixedUpdate is called along with the physics engine, at regular time intervals 
	// It's often used whenever you want to interact with physics components, as we do here
	void FixedUpdate () {

		//we can't directly modify a Vector2 property like the velocity of the rigidbody2d, so let's make a copy first
		Vector2 newVelocity = rb.velocity; 

		//now we can just make sure that the horizontal part of the velocity stays constant
		if (newVelocity.x > 0) {
			newVelocity.x = horizontalSpeed;
		} else {
			newVelocity.x = -horizontalSpeed;
		}

		//and make sure that the vertical part doesn't get too high (which might make the ball bounce over the player)
		if (newVelocity.y > maxVerticalSpeed) {
			newVelocity.y = maxVerticalSpeed;
		}
		else if (newVelocity.y < -maxVerticalSpeed) {
			newVelocity.y = -maxVerticalSpeed;
		}

		//now that we've modified the Vector2, we can copy it back to the velocity property on the component
		rb.velocity = newVelocity;
	}
}
