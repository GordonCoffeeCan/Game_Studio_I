﻿using UnityEngine;
using System.Collections;

public class Hat : MonoBehaviour
{

    GameObject scoreManager;
    GameObject player;
    AudioSource audioSource;

    // Start() is called at the beginning of the game
    void Start()
    {
        scoreManager = GameObject.Find("ScoreManager");//fill the scoreManager variable with a reference to the Score Manager
        player = GameObject.Find("Player"); //fill player Variable with reference to Player
    }

    //OnCollisionEnter2D() is called by the unity engine under the following conditions
    //1. The object that the script is on has a Collider2D set to 'Collider' mode(could be a box, circle, etc)
    //2. The object that the script is on is touching another object with *at least* a Collider2D on it.
    //The function receives the a Collision2D component as a parameter
    void OnCollisionEnter2D(Collision2D collision)
    {
        //check to see if the colliding object had the tag 'Ground'
        if (collision.collider.tag == "Ground")
        {
            //And tell the scoreManager & player that the player missed a hat
            scoreManager.SendMessage("HatMissed");
            player.SendMessage("HatMissed");
            //Then destroy the hat, destroy needs to be sent a game object, which we can get from this.gameObject
            Destroy(this.gameObject);

        }
        //check to see if the colliding object had the tag 'Player'
        if (collision.collider.tag == "Player")
        {
            //Tell the scoreManager & player that the player missed a hat
            scoreManager.SendMessage("HatCaught");
            player.SendMessage("HatCaught");
            //Then destroy the hat, destroy needs to be sent a game object, which we can get from this.gameObject
            Destroy(this.gameObject);
        }
    }
}