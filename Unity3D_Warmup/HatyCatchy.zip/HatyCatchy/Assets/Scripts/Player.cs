﻿using UnityEngine;
using System.Collections;

//This script is a simple player controller
public class Player : MonoBehaviour {
    //public variables like this one are accessible to other scripts, and often set in the inspector
    //they're great for tunable variables because we can change them while the game is running
    public float moveSpeed = 2;

    public Sprite sadPlayerSprite;
    public Sprite happyPlayerSprite;

    //private variables have to be set in code, like Phaser's global variables
    private Rigidbody2D rb;
    private SpriteRenderer sr;
    // Use this for initialization
    void Start ()
    {
        //fill the Rigidbody2D variable with a reference to the Rigidbody2D on this GameObject
        rb = GetComponent<Rigidbody2D>();
        //fill the SpriteRenderer variable with a reference to the SpriteRender on this GameObject
        sr = GetComponent<SpriteRenderer>();
    }
	
	// Update is called once per frame
	void Update ()
	{
        //int for speed multiplier
	    int speedMultiplier;

        //Input.GetButton looks for the button named in the Input manager (Edit->Project Settings->Input)
        //if you want to check if a button is pressed instead of held down, use Input.GetButtonDown
        if (Input.GetButton("Boost"))
	    {
            //when boosting, move speed will be multiplied by 2
	        speedMultiplier = 2;
	    }
	    else
	    {
            //otherwise, move speed will be mutiplied by 1
            speedMultiplier = 1;
        }

        //Input.GetAxis lets you use arrows, WASD, joysticks, etc.
        //These are also mapped in the Input Manager (Edit->Project Settings->Input)
        if (Input.GetAxis("Horizontal") > 0)
        {
            //set the velocity of the rigid body
            rb.velocity = new Vector2(moveSpeed * speedMultiplier, rb.velocity.y);
        }
        if (Input.GetAxis("Horizontal") < 0)
        {
            //set the velocity of the rigid body
            rb.velocity = new Vector2(-moveSpeed * speedMultiplier, rb.velocity.y);
        }
    }

    //To receive the message 'HatCaught' we need to have a public function with that name
    //This is called by the Hat script on each Hat, using SendMessage()
    public void HatCaught()
    {
        sr.sprite = happyPlayerSprite;
    }

    //To receive the message 'HatMissed' we need to have a public function with that name
    //This is called by the Hat script on each Hat, using SendMessage()
    public void HatMissed()
    {
        sr.sprite = sadPlayerSprite;
    }
}
